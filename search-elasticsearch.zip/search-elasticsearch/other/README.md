Need Python ElasticSearch installed
